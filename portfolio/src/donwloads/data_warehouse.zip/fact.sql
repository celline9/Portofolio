--Sales Fact
IF EXISTS ( SELECT * FROM [HOSPITALLE_OLAP]..FilterTimeStamp WHERE TableName = 'SalesFact' )
BEGIN
    SELECT
        CustomerCode,
        StaffCode,
        MedicineCode,
        SUM(tsd.Quantity * MedicineSellingPrice) AS TotalSalesEarning,
		SUM(tsd.Quantity) AS TotalMedicineSold 
    FROM
        [OLTP_HospitalIE]..TrSalesHeader as tsh
        JOIN [OLTP_HospitalIE]..TrSalesDetail tsd ON tsh.SalesID = tsd.SalesID
        JOIN [HOSPITALLE_OLAP]..CustomerDimension cd ON cd.CustomerID = tsh.CustomerID
        JOIN [HOSPITALLE_OLAP]..StaffDimension sd ON sd.StaffID = tsh.StaffID
        JOIN [HOSPITALLE_OLAP]..MedicineDimension md ON tsd.MedicineID = md.MedicineID
    WHERE tsh.SalesDate > (
        SELECT fts.LastETL
        FROM [HOSPITALLE_OLAP]..FilterTimeStamp fts
        WHERE TableName = 'SalesFact'
    )
    GROUP BY CustomerCode, StaffCode, MedicineCode
END
ELSE
BEGIN
    SELECT
        CustomerCode,
        StaffCode,
        MedicineCode,
        SUM(tsd.Quantity * MedicineSellingPrice) AS TotalSalesEarning,
		SUM(tsd.Quantity) AS TotalMedicineSold 
    FROM
        [OLTP_HospitalIE]..TrSalesHeader as tsh
        JOIN [OLTP_HospitalIE]..TrSalesDetail tsd ON tsh.SalesID = tsd.SalesID
        JOIN [HOSPITALLE_OLAP]..CustomerDimension cd ON cd.CustomerID = tsh.CustomerID
        JOIN [HOSPITALLE_OLAP]..StaffDimension sd ON sd.StaffID = tsh.StaffID
        JOIN [HOSPITALLE_OLAP]..MedicineDimension md ON tsd.MedicineID = md.MedicineID
    GROUP BY CustomerCode, StaffCode, MedicineCode
END

select MedicineSellingPrice from medicineDimension


--Update
IF EXISTS (
	SELECT * FROM FilterTimeStamp
	WHERE TableName = 'SalesFact'
)
BEGIN
	UPDATE FilterTimeStamp
	SET LastETL = GETDATE()
	WHERE TableName = 'SalesFact'
END
ELSE
BEGIN
	INSERT INTO FilterTimeStamp
	VALUES ('SalesFact', GETDATE())
END

--PurchaseTransactionFact
IF EXISTS ( SELECT * FROM [HOSPITALLE_OLAP]..FilterTimeStamp WHERE TableName = 'PurchaseTransactionFact' )
BEGIN
    SELECT
        dd.DistributorCode,
        sd.StaffCode,
        md.MedicineCode,
        SUM(tpd.Quantity * md.MedicineBuyingPrice) AS TotalPurchaseCost,
        SUM(tpd.Quantity) AS TotalMedicinePurchased 
    FROM
        [OLTP_HospitalIE]..TrPurchaseHeader tph
        JOIN [OLTP_HospitalIE]..TrPurchaseDetail tpd ON tph.PurchaseID = tpd.PurchaseID
        JOIN [HOSPITALLE_OLAP]..StaffDimension sd ON sd.StaffID = tph.StaffID
        JOIN [HOSPITALLE_OLAP]..MedicineDimension md ON md.MedicineID = tpd.MedicineID
        JOIN [HOSPITALLE_OLAP]..DistributorDimension dd ON dd.DistributorID = tph.DistributorID
    WHERE tph.PurchaseDate > (
        SELECT fts.LastETL
        FROM [HOSPITALLE_OLAP]..FilterTimeStamp fts
        WHERE TableName = 'PurchaseTransactionFact'
    )
    GROUP BY dd.DistributorCode, sd.StaffCode, md.MedicineCode
END
ELSE
BEGIN
    SELECT
        dd.DistributorCode,
        sd.StaffCode,
        md.MedicineCode,
        SUM(tpd.Quantity * md.MedicineBuyingPrice) AS TotalPurchaseCost,
        SUM(tpd.Quantity) AS TotalMedicinePurchased 
    FROM
        [OLTP_HospitalIE]..TrPurchaseHeader tph
        JOIN [OLTP_HospitalIE]..TrPurchaseDetail tpd ON tph.PurchaseID = tpd.PurchaseID
        JOIN [HOSPITALLE_OLAP]..StaffDimension sd ON sd.StaffID = tph.StaffID
        JOIN [HOSPITALLE_OLAP]..MedicineDimension md ON md.MedicineID = tpd.MedicineID
        JOIN [HOSPITALLE_OLAP]..DistributorDimension dd ON dd.DistributorID = tph.DistributorID
    GROUP BY dd.DistributorCode, sd.StaffCode, md.MedicineCode
END

select * from [oltp_hospitalie]..trpurchasedetail

IF EXISTS (
	SELECT * FROM FilterTimeStamp
	WHERE TableName = 'PurchaseTransactionFact'
)
BEGIN
	UPDATE FilterTimeStamp
	SET LastETL = GETDATE()
	WHERE TableName = 'PurchaseTransactionFact'
END
ELSE
BEGIN
	INSERT INTO FilterTimeStamp
	VALUES ('PurchaseTransactionFact', GETDATE())
END

--SubscriptionTransactionFact
IF EXISTS ( SELECT * FROM [HOSPITALLE_OLAP]..FilterTimeStamp WHERE TableName = 'SubscriptionTransactionFact' )
BEGIN
    SELECT
        StaffCode,
		CustomerCode,
		BenefitCode,
        SUM(BenefitPrice) AS TotalSubscriptionEarning,
		COUNT(tsd.SubscriptionID) AS SubscriberCount
    FROM
        [OLTP_HospitalIE]..TrSubscriptionHeader tsh
        JOIN [OLTP_HospitalIE]..TrSubscriptionDetail tsd ON tsh.SubscriptionID = tsd.SubscriptionID
        JOIN [HOSPITALLE_OLAP]..StaffDimension sd ON sd.StaffID = tsh.StaffID
		JOIN [HOSPITALLE_OLAP]..BenefitDimension bd ON bd.BenefitID = tsd.BenefitID
		JOIN [HOSPITALLE_OLAP]..CustomerDimension cd ON cd.CustomerID = tsh.CustomerID
    WHERE tsh.SubscriptionStartDate > (
        SELECT fts.LastETL
        FROM [HOSPITALLE_OLAP]..FilterTimeStamp fts
        WHERE TableName = 'SubscriptionTransactionFact'
    )
    GROUP BY StaffCode, CustomerCode, BenefitCode
END
ELSE
BEGIN
       SELECT
        StaffCode,
		CustomerCode,
		BenefitCode,
        SUM(BenefitPrice) AS TotalSubscriptionEarning,
		COUNT(tsd.SubscriptionID) AS SubscriberCount
    FROM
        [OLTP_HospitalIE]..TrSubscriptionHeader tsh
        JOIN [OLTP_HospitalIE]..TrSubscriptionDetail tsd ON tsh.SubscriptionID = tsd.SubscriptionID
        JOIN [HOSPITALLE_OLAP]..StaffDimension sd ON sd.StaffID = tsh.StaffID
		JOIN [HOSPITALLE_OLAP]..BenefitDimension bd ON bd.BenefitID = tsd.BenefitID
		JOIN [HOSPITALLE_OLAP]..CustomerDimension cd ON cd.CustomerID = tsh.CustomerID
    GROUP BY StaffCode, CustomerCode, BenefitCode
END

IF EXISTS (
	SELECT * FROM FilterTimeStamp
	WHERE TableName = 'SubscriptionTransactionFact'
)
BEGIN
	UPDATE FilterTimeStamp
	SET LastETL = GETDATE()
	WHERE TableName = 'SubscriptionTransactionFact'
END
ELSE
BEGIN
	INSERT INTO FilterTimeStamp
	VALUES ('SubscriptionTransactionFact', GETDATE())
END

select * from [OLTP_HospitalIE]..TrSubscriptionHeader
select * from [OLTP_HospitalIE]..TrSubscriptionDetail


--ServiceTransactionFact
IF EXISTS ( SELECT * FROM [HOSPITALLE_OLAP]..FilterTimeStamp WHERE TableName = 'ServiceTransactionFact' )
BEGIN
    SELECT
        dd.DoctorCode,
        cd.CustomerCode,
        td.TreatmentCode,
        SUM(trd.quantity * td.TreatmentPrice) AS TotalServiceEarning,  
        COUNT(DISTINCT trh.DoctorID) AS DoctorCount  
    FROM
        [OLTP_HospitalIE]..TrServiceHeader trh
        JOIN [OLTP_HospitalIE]..TrServiceDetail trd ON trh.ServiceID = trd.ServiceID
        JOIN [HOSPITALLE_OLAP]..CustomerDimension cd ON cd.CustomerID = trh.CustomerID
        JOIN [HOSPITALLE_OLAP]..TreatmentDimension td ON td.TreatmentID = trd.TreatmentID
        JOIN [HOSPITALLE_OLAP]..DoctorDimension dd ON dd.DoctorID = trh.DoctorID
    WHERE trh.ServiceDate > (
        SELECT fts.LastETL
        FROM [HOSPITALLE_OLAP]..FilterTimeStamp fts
        WHERE TableName = 'ServiceTransactionFact'
    )
    GROUP BY dd.DoctorCode, cd.CustomerCode, td.TreatmentCode
END
ELSE
BEGIN
    SELECT
        dd.DoctorCode,
        cd.CustomerCode,
        td.TreatmentCode,
        SUM(trd.quantity * td.TreatmentPrice) AS TotalServiceEarning,
        COUNT(DISTINCT trh.DoctorID) AS DoctorCount
    FROM
        [OLTP_HospitalIE]..TrServiceHeader trh
        JOIN [OLTP_HospitalIE]..TrServiceDetail trd ON trh.ServiceID = trd.ServiceID
        JOIN [HOSPITALLE_OLAP]..CustomerDimension cd ON cd.CustomerID = trh.CustomerID
        JOIN [HOSPITALLE_OLAP]..TreatmentDimension td ON td.TreatmentID = trd.TreatmentID
        JOIN [HOSPITALLE_OLAP]..DoctorDimension dd ON dd.DoctorID = trh.DoctorID
    GROUP BY dd.DoctorCode, cd.CustomerCode, td.TreatmentCode
END

IF EXISTS (
	SELECT * FROM FilterTimeStamp
	WHERE TableName = 'ServiceTransactionFact'
)
BEGIN
	UPDATE FilterTimeStamp
	SET LastETL = GETDATE()
	WHERE TableName = 'ServiceTransactionFact'
END
ELSE
BEGIN
	INSERT INTO FilterTimeStamp
	VALUES ('ServiceTransactionFact', GETDATE())
END

select * from OLTP_HospitalIE..MsTreatment

select * from serviceTransactionfact
select * from purchasetransactionfact
select * from subscriptiontransactionfact
select * from salesfact