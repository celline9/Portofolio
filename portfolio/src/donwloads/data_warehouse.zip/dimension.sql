CREATE DATABASE HOSPITALLE_OLAP
USE HOSPITALLE_OLAP

CREATE TABLE MedicineDimension(
	MedicineCode INT PRIMARY KEY IDENTITY(1,1),
	MedicineID INT,
	MedicineName VARCHAR(255),
	MedicineExpiredDate DATE,
	MedicineSellingPrice BIGINT,
	MedicineBuyingPrice BIGINT
)

CREATE TABLE StaffDimension(
	StaffCode INT PRIMARY KEY IDENTITY(1,1),
	StaffID INT, 
	StaffName VARCHAR(255), 
	StaffDOB DATE,
	StaffGender VARCHAR(255), 
	StaffAddress VARCHAR(255),
	StaffSalary BIGINT,
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE DoctorDimension(
	DoctorCode INT PRIMARY KEY IDENTITY(1,1),
	DoctorID INT, 
	DoctorName VARCHAR(255), 
	DoctorDOB DATE,
	DoctorAddress VARCHAR(255),
	DoctorSalary BIGINT,
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE CustomerDimension(
	CustomerCode INT PRIMARY KEY IDENTITY(1,1),
	CustomerID INT, 
	CustomerDOB DATE,
	CustomerName VARCHAR(50), 
	CustomerGender VARCHAR(50), 
	CustomerAddress VARCHAR(50),
)

CREATE TABLE BenefitDimension(
	BenefitCode INT PRIMARY KEY IDENTITY(1,1),
	BenefitID INT,
	BenefitName VARCHAR(50),
	BenefitPrice BIGINT,
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE TreatmentDimension(
	TreatmentCode INT PRIMARY KEY IDENTITY(1,1),
	TreatmentID INT,
	TreatmentName VARCHAR(50),
	TreatmentPrice DECIMAL(10,2),
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE DistributorDimension(
	DistributorCode INT PRIMARY KEY IDENTITY(1,1),
	DistributorID INT,
	CityID INT,
	DistributorName VARCHAR(255),
	DistributorAddress VARCHAR(255),
	DistributorPhone VARCHAR(255),
)

CREATE TABLE TimeDimension (
	TimeCode INT PRIMARY KEY IDENTITY(1,1),
	[Date] DATE,
	[Day] INT, 
	[Month] INT, 
	[Quarter] INT, 
	[Year] INT, 
)

SELECT CustomerID, 
	CustomerDOB,
	CustomerName, 
	CustomerGender, 
	CustomerAddress
from mscustomer

SELECT
	StaffID, 
	StaffName, 
	StaffDOB,
	StaffGender, 
	StaffAddress,
	StaffSalary
from msstaff

SELECT
DoctorID, DoctorName, DoctorDOB, DoctorAddress,
	DoctorSalary
FROM MsDoctor

select * from CustomerDimension
select * from DoctorDimension
SELECT BenefitID, BenefitName, BenefitPrice 
from msBenefit

SELECT
	DistributorID,
	CityID,
	DistributorName,
	DistributorAddress,
	DistributorPhone
FROM MsDistributor

SELECT * FROM DistributorDimension
SELECT * FROM MedicineDimension

SELECT
MedicineID,
	MedicineName,
	MedicineExpiredDate,
	MedicineSellingPrice,
	MedicineBuyingPrice
FROM MsMedicine

CREATE TABLE FilterTimeStamp (
	TableName VARCHAR(50), 
	LastETL Date
);

--Create Table Fact
CREATE TABLE SalesFact(
	MedicineCode INT NOT NULL, 
	StaffCode INT NOT NULL,
	CustomerCode INT NOT NULL,
	TotalSalesEarning BIGINT NOT NULL,
	TotalMedicineSold BIGINT NOT NULL
)

DROP TABLE SalesFact
CREATE TABLE PurchaseTransactionFact(
	MedicineCode INT NOT NULL, 
	DistributorCode INT NOT NULL,
	StaffCode INT NOT NULL,
	TotalPurchaseCost BIGINT NOT NULL,
	TotalMedicinePurchased BIGINT NOT NULL
)

CREATE TABLE SubscriptionTransactionFact(
	StaffCode INT NOT NULL, 
	CustomerCode INT NOT NULL,
	BenefitCode INT NOT NULL,
	TotalSubscriptionEarning BIGINT NOT NULL,
	SubscriberCount BIGINT NOT NULL
)

CREATE TABLE ServiceTransactionFact(
	DoctorCode INT NOT NULL, 
	CustomerCode INT NOT NULL,
	TreatmentCode INT NOT NULL,
	TotalServiceEarning BIGINT NOT NULL,
	DoctorCount BIGINT NOT NULL
)

SELECT * FROM TimeDimension


--Create ETL Fact
IF EXISTS (
SELECT * FROM [HOSPITALLE_OLAP]..FilterTimeStamp
WHERE TableName = 'TimeDimension'
)
BEGIN
SELECT DISTINCT x.Date AS [DATE],
		DAY(x.Date) AS [Day],
		MONTH(x.Date) AS [Month],
		DATEPART(QUARTER, x.Date) AS [Quarter],
		YEAR(x.Date) AS [Year]
	FROM
		(
			SELECT SalesDate AS [Date]
			FROM [OLTP_HospitalIE]..TrSalesHeader
			UNION
			SELECT
			PurchaseDate AS [Date] FROM [OLTP_HospitalIE]..TrPurchaseHeader
		) as x, [HOSPITALLE_OLAP]..FilterTimeStamp as fts
	WHERE x.[Date] > fts.LastETL
	AND fts.TableName = 'TimeDimension'
END
ELSE
BEGIN
		SELECT DISTINCT x.Date AS [DATE],
		DAY(x.Date) AS [Day],
		MONTH(x.Date) AS [Month],
		DATEPART(QUARTER, x.Date) AS [Quarter],
		YEAR(x.Date) AS [Year]
FROM
		(
			SELECT
			SalesDate AS [Date]
			FROM
			[OLTP_HospitalIE]..TrSalesHeader
			UNION
			SELECT
			PurchaseDate AS [Date] FROM [OLTP_HospitalIE]..TrPurchaseHeader
		) as x
END

--Query untuk update FilterTimeStamp
IF EXISTS (
	SELECT * FROM FilterTimeStamp
	WHERE TableName = 'TimeDimension'
)
BEGIN
	UPDATE FilterTimeStamp
	SET LastETL = GETDATE()
	WHERE TableName = 'TimeDimension'
END
ELSE
BEGIN
	INSERT INTO FilterTimeStamp
	VALUES ('TimeDimension', GETDATE())
END


--Update
IF EXISTS (
	SELECT * FROM FilterTimeStamp
	WHERE TableName = 'TimeDimension'
)
BEGIN
	UPDATE FilterTimeStamp
	SET LastETL = GETDATE()
	WHERE TableName = 'TimeDimension'
END
ELSE
BEGIN
	INSERT INTO FilterTimeStamp
	VALUES ('TimeDimension', GETDATE())
END

select * from SalesFact

select * from DistributorDimension
select * from salesfact

