CREATE DATABASE HOSPITALLE_OLAP
USE HOSPITALLE_OLAP

CREATE TABLE MedicineDimension(
	MedicineCode INT PRIMARY KEY IDENTITY(1,1),
	MedicineID INT,
	MedicineName VARCHAR(20),
	MedicineExpiredDate DATE,
	MedicineSellingPrice INT,
	MedicineBuyingPrice INT,
	ValidFrom DATETIME,
	ValidTo DATETIME
)

CREATE TABLE StaffDimension(
	StaffCode INT PRIMARY KEY IDENTITY(1,1),
	StaffID INT, 
	StaffName VARCHAR(50), 
	StaffDOB DATE,
	StaffGender VARCHAR(20), 
	StaffSalary INT,
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE DoctorDimension(
	DoctorCode INT PRIMARY KEY IDENTITY(1,1),
	DoctorID INT, 
	DoctorName VARCHAR(50), 
	DoctorDOB DATE,
	DoctorAddress VARCHAR(50),
	DoctorSalary INT,
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE CustomerDimension(
	CustomerCode INT PRIMARY KEY IDENTITY(1,1),
	CustomerID INT, 
	CustomerDOB DATE,
	CustomerName VARCHAR(50), 
	CustomerGender VARCHAR(50), 
	CustomerAddress VARCHAR(50),
)

CREATE TABLE BenefitDimension(
	BenefitCode INT PRIMARY KEY IDENTITY(1,1),
	BenefitID INT,
	BenefitName VARCHAR(50),
	BenefitPrice DECIMAL(10,2),
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE TreatmentDimension(
	TreatmentCode INT PRIMARY KEY IDENTITY(1,1),
	TreatmentID INT,
	TreatmentName VARCHAR(50),
	TreatmentPrice DECIMAL(10,2),
	ValidFrom DATETIME, 
	ValidTo DATETIME
)

CREATE TABLE DistributorDimension(
	DistributorCode INT PRIMARY KEY IDENTITY(1,1),
	DistributorID INT,
	CityID CHAR(7),
	DistributorName VARCHAR(50),
	DistributorAddress VARCHAR(50),
	DistributorPhone VARCHAR(20),

)

CREATE TABLE TimeDimension (
	TimeCode INT PRIMARY KEY IDENTITY(1,1),
	[Date] DATE,
	[Day] INT, 
	[Month] INT, 
	[Quarter] INT, 
	[Year] INT, 
)
SELECT * FROM MsStaff
select * from msdistributor
